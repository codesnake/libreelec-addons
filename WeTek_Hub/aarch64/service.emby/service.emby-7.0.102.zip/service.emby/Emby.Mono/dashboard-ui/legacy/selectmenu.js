﻿// TODO: This needs to be deprecated, but it's used heavily by plugins
$.fn.selectmenu = function () {
    // No-op. This implementation only exists to prevent script errors
    return this;
};